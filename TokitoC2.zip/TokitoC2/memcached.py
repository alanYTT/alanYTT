from scapy.all import IP, UDP, send, sr1, Raw
import time

ip_base = "192.168.0."  # Cambia esto si quieres escanear redes públicas
puerto = 11211
timeout = 2
resultados = []

def es_vulnerable(ip):
    try:
        pkt = IP(dst=ip)/UDP(sport=4444, dport=puerto)/Raw(load=b'\x00\x01\x00\x00\x00\x01\x00\x00stats\r\n')
        respuesta = sr1(pkt, timeout=timeout, verbose=0)
        if respuesta:
            return True
    except:
        pass
    return False

def escanear_rango(rango_inicial, rango_final):
    inicio = time.time()
    for i in range(rango_inicial, rango_final + 1):
        ip = ip_base + str(i)
        print(f"[+] Escaneando {ip}...")
        if es_vulnerable(ip):
            print(f"[!] {ip} es VULNERABLE")
            resultados.append(ip)
            with open("vulnerables.txt", "a") as f:
                f.write(ip + "\n")
    fin = time.time()
    
    # Eliminar duplicados
    try:
        with open("vulnerables.txt", "r") as f:
            unicas = sorted(set(f.read().splitlines()))
        with open("vulnerables.txt", "w") as f:
            f.write("\n".join(unicas))
    except:
        pass

    print(f"\nEscaneo terminado en {round(fin - inicio, 2)} segundos.")
    print(f"IPs vulnerables encontradas: {len(resultados)}")
    print(f"Guardadas en vulnerables.txt")

# Cambia el rango aquí (puedes poner 1-254 para red local)
escanear_rango(1, 254)
